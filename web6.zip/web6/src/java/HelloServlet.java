import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.regex.*;

public class HelloServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        HttpSession session = request.getSession();

        String name = request.getParameter("name");
        
     
        Pattern pattern = Pattern.compile("^[A-Za-z\\s]{3,20}$");
        Matcher matcher = pattern.matcher(name);
        if (name == null || name.trim().isEmpty() || !matcher.matches()) {
            response.sendRedirect("index.html");
            return;
        }

        session.setAttribute("username", name);

        Date startTime;
        if (session.getAttribute("startTime") == null) {
            startTime = new Date();
            session.setAttribute("startTime", startTime);
        } else {
            startTime = (Date) session.getAttribute("startTime");
        }

        Integer visitCount = (Integer) session.getAttribute("visitCount");
        if (visitCount == null) {
            visitCount = 1;
        } else {
            visitCount++;
        }
        session.setAttribute("visitCount", visitCount);

        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");

        out.println("<html><head><title>Hello Page</title>");
        out.println("<style>body { font-family: Arial, sans-serif; text-align: center; }");
        out.println(".top-right { position: absolute; top: 10px; right: 10px; font-size: 14px; }</style>");
        out.println("</head><body>");

        out.println("<div class='top-right'>Start Time: " + formatter.format(startTime) + "</div>");
        out.println("<h2>Hello, " + name + "!</h2>");
        out.println("<p>Session ID: " + session.getId() + "</p>");
        out.println("<p>Number of Visits: " + visitCount + "</p>");

        out.println("<form action='LogoutServlet' method='post'>");
        out.println("<input type='submit' value='Logout' style='background-color:red; color:white; padding:10px;'>");
        out.println("</form>");

        out.println("</body></html>");
    }
}
