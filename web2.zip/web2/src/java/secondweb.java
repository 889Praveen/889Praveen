/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ashwin
 */
public class secondweb extends HttpServlet {

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

     
        PrintWriter out = response.getWriter();

       
        out.println("==== Servlet Init Parameters ====");
        ServletConfig config=getServletConfig();
        String param1 = getServletConfig().getInitParameter("user");
        String param2 = getServletConfig().getInitParameter("password");
        out.println("Init Parameter - param1: " + param1);
        out.println("Init Parameter - param2: " + param2);

        // 2. Print HTTP Request Headers (hardcoded for a few common headers)
        out.println("\n==== HTTP Request Headers ====");
        String host = request.getHeader("Host");
     
        String userAgent = request.getHeader("User-Agent");
        String acceptLanguage = request.getHeader("Accept-Language");

        out.println("Host: " + host);
        out.println("User-Agent: " + userAgent);
        out.println("Accept-Language: " + acceptLanguage);

        // 3. Print Client/Browser Information
        out.println("\n==== Client/Browser Information ====");
        String clientIP = request.getRemoteAddr();
        String clientHost = request.getRemoteHost();
        out.println("Client IP: " + clientIP);
        out.println("Client Host: " + clientHost);
        out.println("User-Agent (Browser/Client Info): " + userAgent);

        // 4. Print Server Details
        out.println("\n==== Server Details ====");
        ServletContext context = getServletContext();
        
        String serverInfo = context.getServerInfo();
       
        String serverName = request.getServerName();
        out.println("Server Info: " + serverInfo);
        out.println("Server Name: " + serverName);
    }
}



