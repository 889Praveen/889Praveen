

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class update extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet update</title>");            
            out.println("</head>");
            out.println("<body>");
           
            try
            {
             String userId = request.getParameter("id");
            String newUserName = request.getParameter("name");
            String newOwnerName = request.getParameter("owner");
            
            
             Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc2025","root","");
            
            
                if (userId == null || userId.isEmpty() || newUserName == null || newUserName.isEmpty() || newOwnerName == null || newOwnerName.isEmpty()) {
                out.println("<html><body><h2>All fields are required.</h2></body></html>");
                return;
            }
            
                
                String sql = "UPDATE user_info SET user_name = ?, owner_name = ? WHERE user_id = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, newUserName);
                ps.setString(2, newOwnerName);
                ps.setString(3, userId);
                
                
                        int rowsAffected = ps.executeUpdate();

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                     
if (rowsAffected > 0) {
  

    String selectSql = "SELECT * FROM user_info WHERE user_id = ?";
    PreparedStatement psSelect = conn.prepareStatement(selectSql);
    psSelect.setString(1, userId);

    ResultSet rs = psSelect.executeQuery();

   
    out.println("<h3 style='text-align:center;'>Update Data Successfully....!:</h3>");
    out.println("<table style='width:60%; margin: 0 auto; border-collapse: collapse;'>");
    out.println("<tr style='background-color:#f2f2f2;'><th style='padding:10px; text-align:left;'>User ID</th><th style='padding:10px; text-align:left;'>User Name</th><th style='padding:10px; text-align:left;'>Owner Name</th></tr>");

    while (rs.next()) {
        out.println("<tr>");
        out.println("<td style='padding:10px; border: 1px solid #ddd;'>" + rs.getString("user_id") + "</td>");
        out.println("<td style='padding:10px; border: 1px solid #ddd;'>" + rs.getString("user_name") + "</td>");
        out.println("<td style='padding:10px; border: 1px solid #ddd;'>" + rs.getString("owner_name") + "</td>");
        out.println("</tr>");
    }
     
    out.println("</table>");
 out.println("<br><center>");
  out.println(" <a href='update.html'>Go Back</a>");
   out.println("</center>");
    rs.close();
    psSelect.close();
} else {
    out.println("<h2 style='color:red; text-align:center;'>Data Update failed!</h2>");
     out.println("<br><center>");
  out.println(" <a href='update.html'>Go Back</a>");
   out.println("</center>");
}
  
  
                
                
                
                
                
                
                
                
                
                
                
                
                
            }catch(Exception e)
            {
                e.printStackTrace();
            }
            
            
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
