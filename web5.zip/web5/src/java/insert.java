/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 *
 * @author st
 */
public class insert extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet insert</title>");            
            out.println("</head>");
            out.println("<body>");
           String id =request.getParameter("id");
           String name=request.getParameter("name");
           String owner=request.getParameter("owner");

             try {
           
            Class.forName("com.mysql.jdbc.Driver");

            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc2025","root","");

             
String checkSql = "SELECT COUNT(*) FROM user_info WHERE user_id = ?";
                PreparedStatement psCheck = conn.prepareStatement(checkSql);
                psCheck.setString(1, id);
                ResultSet rsCheck = psCheck.executeQuery();
                
                rsCheck.next();
                int count = rsCheck.getInt(1);
                
                if (count > 0) {
                    // If user_id already exists, inform the user
                    out.println("<h2 style='color:red; text-align:center;'>User ID already exists!</h2>");
                    out.println("<br><center>");
                    out.println("<a href='add.html'>Go Back</a>");
                    out.println("</center>");
                } else {
            String sql = "INSERT INTO user_info (user_id, user_name, owner_name) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.setString(2, name);
            ps.setString(3, owner);

          
            int rowsAffected = ps.executeUpdate();

            
            
            
if (rowsAffected > 0) {
    out.println("<h2 style='color:green; text-align:center;'>Data inserted successfully!</h2>");

    String selectSql = "SELECT * FROM user_info WHERE user_id = ?";
    PreparedStatement psSelect = conn.prepareStatement(selectSql);
    psSelect.setString(1, id);

    ResultSet rs = psSelect.executeQuery();

   
    out.println("<h3 style='text-align:center;'>Inserted Data:</h3>");
    out.println("<table style='width:60%; margin: 0 auto; border-collapse: collapse;'>");
    out.println("<tr style='background-color:#f2f2f2;'><th style='padding:10px; text-align:left;'>User ID</th><th style='padding:10px; text-align:left;'>User Name</th><th style='padding:10px; text-align:left;'>Owner Name</th></tr>");

    while (rs.next()) {
        out.println("<tr>");
        out.println("<td style='padding:10px; border: 1px solid #ddd;'>" + rs.getString("user_id") + "</td>");
        out.println("<td style='padding:10px; border: 1px solid #ddd;'>" + rs.getString("user_name") + "</td>");
        out.println("<td style='padding:10px; border: 1px solid #ddd;'>" + rs.getString("owner_name") + "</td>");
        out.println("</tr>");
    }
     
    out.println("</table>");
 out.println("<br><center>");
  out.println(" <a href='add.html'>Go Back</a>");
   out.println("</center>");
    rs.close();
    psSelect.close();
} else {
    out.println("<h2 style='color:red; text-align:center;'>Data insertion failed!</h2>");
    out.println("<br><center>");
  out.println(" <a href='add.html'>Go Back</a>");
   out.println("</center>");
}
  
  

            // Close connections
            ps.close();
            conn.close();
}
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Database error: " + e.getMessage());
        }
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
