/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
/*
import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class myfistwebproject extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve input values
        String principalParam = request.getParameter("Principal");
        String interestParam = request.getParameter("Interest");
        String yearsParam = request.getParameter("Years");
        String monthsParam = request.getParameter("Months");
        String compoundParam = request.getParameter("cars");

        String errorMessage = "";
        long principal;
        double interest;
        int years ;
        int months ;
        
    
        
         
         interest = Double.parseDouble(interestParam);
         years = Integer.parseInt(yearsParam);
         months = Integer.parseInt(monthsParam);
         
        String regex = "^\\d+(\\.\\d{1,2})?$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(principalParam);
         principal = Long.parseLong(principalParam);
           if (principalParam != null && matcher.matches())
           {
              
                if(principal>0)
                    {
                     try {
                       if (principal > 1000000 ) 
                           {
                             errorMessage += "Principal amount cannot be more than 1000000!<br>";
                           }
                          } 
                        catch (NumberFormatException e)
                          {
                            errorMessage += "Please enter a valid principal amount (numeric value).<br>";
                          }
                    }
                     else
                    {
                      errorMessage += "Principal amount  more than 0!";
                    }
            } 
            else
            {
               errorMessage="Invalid input. Please provide a valid numeric value...!";
            }
           
        
         
       // String regex1 = "^\\d+(\\.\\d{1,2})?$";
        //Pattern pattern1 = Pattern.compile(regex1);
        //Matcher matcher1 = pattern1.matcher(interestParam);
        //if (interestParam != null && matcher1.matches())
        //   {
            if(interest>0)
             {
               try {
               if (interest > 100) 
                 {
                   errorMessage += "Interest cannot be more than 100%.<br>";
                 }
               } 
               catch (NumberFormatException e) 
               {
                  errorMessage += "Please enter a valid interest rate (numeric value).<br>";
               }
             }
             else
             {
               errorMessage += "Please Enter interest more then 0! .<br>";
             }
          // }
      //  else
        //{
     //    errorMessage="Invalid input. Please provide a valid numeric value";
       // }
        
        
        
        
        
        
        if((years<=0 && months <=0) || years<0 || months>12 )
        {
        
          errorMessage +="Enter Valid Years and Months!<br>";
        }else
        {
        try {
            
            
            if (years > 9999) 
            {
                errorMessage += "Years cannot be more than 9999.<br>";
            }
        } catch (NumberFormatException e)
        {
            errorMessage += "Please enter a valid number of years.<br>";
        }

        
        
        try {
           
            if (months > 11)
            {
                errorMessage += "Months cannot be more than 11.<br>";
            }
        } catch (NumberFormatException e)
        {
            errorMessage += "Please enter a valid number of months (0-11).<br>";
        }
    
        }
        int compound = 0;
        try {
            compound = Integer.parseInt(compoundParam);
        } catch (NumberFormatException e) {
            errorMessage += "Please enter a valid number of compounds per year.<br>";
        }

      
        if (!errorMessage.isEmpty()) {
            out.println("<html>");
            out.println("<body>");
            out.println("<p>" + errorMessage + "</p>");
            out.println("<form action='index.html'>");
            out.println("<button type='submit'>Return to Form</button>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
            return;  
        }

     
  try {
            double time = years + (months / 12.0); 
            double compoundInterest = principal * (1 + interest / (compound * 100)) * compound * time;


out.println("<html>");
out.println("<head><title>Compound Interest Calculation</title>");
out.println("<style>");
out.println("body {");
out.println("  font-family: Arial, sans-serif;");
out.println("  background-color: #f4f4f9;");
out.println("  margin: 20px;");
out.println("  padding: 20px;");
out.println("}");
out.println("h1 {");
out.println("  color: #4CAF50;");
out.println("  text-align: center;");
out.println("}");
out.println("table {");
out.println("  width: 50%;");
out.println("  margin: 20px auto;");
out.println("  border-collapse: collapse;");
out.println("  background-color: #ffffff;");
out.println("}");
out.println("th, td {");
out.println("  padding: 10px;");
out.println("  text-align: center;");
out.println("  border: 1px solid #ddd;");
out.println("}");
out.println("th {");
out.println("  background-color: ;");
out.println("  color: bleak;");
out.println("}");
out.println("tr:nth-child(even) {");
out.println("  background-color: #f2f2f2;");
out.println("}");
out.println("button {");
out.println("  background-color: #4CAF50;");
out.println("  color: white;");
out.println("  padding: 10px 20px;");
out.println("  border: none;");
out.println("  cursor: pointer;");
out.println("  display: block;");
out.println("  margin: 20px auto;");
out.println("  font-size: 16px;");
out.println("}");
out.println("button:hover {");
out.println("  background-color: #45a049;");
out.println("}");
out.println("</style>");

out.println("</head>");
out.println("<body>");
out.println("<h1>Compound Interest Calculation</h1>");


out.println("<table>");
out.println("<tr>");
out.println("<th>Principal Amount</th>");
out.println("<td>" + principalParam+ "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Interest</th>");
out.println("<td>" + interestParam + "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Years</th>");
out.println("<td>" + yearsParam + "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Months</th>");
out.println("<td>" +  monthsParam + "</td>");
out.println("</tr>"); 

out.println("<tr>");
out.println("<th>Compound Interest</th>");
out.println("<td>" + compoundInterest + "</td>");
out.println("</tr>");

out.println("</table>");


out.println("<form action='index.html'>");
out.println("<button type='submit'>Return to Form</button>");
out.println("</form>");

out.println("</body>");
out.println("</html>");


        } 
  catch (Exception e) 
        {
            out.println("<html><body><h3>Error occurred while calculating compound interest.</h3></body></html>");
        }
    }
}
*/




import java.io.*;
import java.util.regex.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class myfistwebproject extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve input values
        String principalParam = request.getParameter("Principal");
        String interestParam = request.getParameter("Interest");
        String yearsParam = request.getParameter("Years");
        String monthsParam = request.getParameter("Months");
        String compoundParam = request.getParameter("cars");

        String errorMessage = "";
        long principal = 0;
        double interest = 0.0;
        int years = 0;
        int months = 0;

        
        String numericPattern = "^[0-9]+(\\.[0-9]{1,2})?$";  
        Pattern pattern = Pattern.compile(numericPattern);

      
        if (principalParam == null || principalParam.isEmpty()) 
        {
            errorMessage += "Please enter a valid Principal amount.<br>";
        } else
        {
            Matcher matcher = pattern.matcher(principalParam);
            if (matcher.matches()) {
                try {
                    principal = Long.parseLong(principalParam);
                    if (principal < 0) {
                        errorMessage += "Principal amount must be greater than 0.<br>";
                    } else if (principal > 1000000) {
                        errorMessage += "Principal amount cannot be more than 1,000,000.<br>";
                    }
                } catch (NumberFormatException e) {
                    errorMessage += "Invalid Principal amount. Please enter a valid number.<br>";
                }
            } else {
                errorMessage += "Principal must be a valid number.<br>";
            }
        }

    
        if (interestParam == null || interestParam.trim().isEmpty())
        {
            errorMessage += "Please enter a valid Interest rate.<br>";
        } else 
        {
            Matcher matcher = pattern.matcher(interestParam);
            if (matcher.matches()) 
            {
                try 
                {
                    interest = Double.parseDouble(interestParam);
                    if (interest <0) 
                    {
                        errorMessage += "Interest rate must be greater than 0.<br>";
                    } else if (interest > 100)
                    {
                        errorMessage += "Interest rate cannot be more than 100%.<br>";
                    }
                } catch (NumberFormatException e)
                {
                    errorMessage += "Invalid Interest rate. Please enter a valid number.<br>";
                }
            } 
            else 
            {
                errorMessage += "Interest must be a valid number.<br>";
            }
        }

       
        
        
        
        
        
       
        
            if (yearsParam == null || yearsParam.trim().isEmpty())
            {
                errorMessage += "Please enter a valid number of Years.<br>";
            }
            else
            {
                try {
                    years = Integer.parseInt(yearsParam);
                    if ((years<=0 && months <=0))
                    {
                        errorMessage += "Please Enetr Years and Months must be greater than 0.<br>";
                    }
                    else if (years > 9999)
                    {
                        errorMessage += "Years cannot be more than 9999.<br>";
                    }
                } catch (NumberFormatException e) {
                    errorMessage += "Invalid number of Years. Please enter a valid number.<br>";
                }
            }
        
        
        
        
        
        
        
        if (monthsParam == null || monthsParam.trim().isEmpty()) 
        {
            errorMessage += "Please enter a valid number of Months.<br>";
        }
        else 
        {
            try {
                months = Integer.parseInt(monthsParam);
                if (months < 0 || months > 11) {
                    errorMessage += "Months must be between 0 and 11.<br>";
                }
            } catch (NumberFormatException e) {
                errorMessage += "Invalid number of Months. Please enter a valid number.<br>";
            }
        }

       
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        int compound = 0;
        if (compoundParam == null || compoundParam.trim().isEmpty())
        {
            errorMessage += "Please enter a valid number of Compounds per year.<br>";
        } 
        else 
        {
            try {
                compound = Integer.parseInt(compoundParam);
            } 
            catch (NumberFormatException e)
            {
                errorMessage += "Invalid number of Compounds per year. Please enter a valid number.<br>";
            }
        }

        
        if (!errorMessage.isEmpty()) 
        {
            out.println("<html>");
            out.println("<body>");
            out.println("<p>" + errorMessage + "</p>");
            out.println("<form action='index.html'>");
            out.println("<button type='submit'>Return to Form</button>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
            return;  
        }

       
        try {
            double time = years + (months / 12.0); 
            double compoundInterest = principal * Math.pow((1 + interest / (compound * 100)), compound * time);

            out.println("<html>");
out.println("<head><title>Compound Interest Calculation</title>");
out.println("<style>");
out.println("body {");
out.println("  font-family: Arial, sans-serif;");
out.println("  background-color: #f4f4f9;");
out.println("  margin: 20px;");
out.println("  padding: 20px;");
out.println("}");
out.println("h1 {");
out.println("  color: #4CAF50;");
out.println("  text-align: center;");
out.println("}");
out.println("table {");
out.println("  width: 50%;");
out.println("  margin: 20px auto;");
out.println("  border-collapse: collapse;");
out.println("  background-color: #ffffff;");
out.println("}");
out.println("th, td {");
out.println("  padding: 10px;");
out.println("  text-align: center;");
out.println("  border: 1px solid #ddd;");
out.println("}");
out.println("th {");
out.println("  background-color: ;");
out.println("  color: bleak;");
out.println("}");
out.println("tr:nth-child(even) {");
out.println("  background-color: #f2f2f2;");
out.println("}");
out.println("button {");
out.println("  background-color: #4CAF50;");
out.println("  color: white;");
out.println("  padding: 10px 20px;");
out.println("  border: none;");
out.println("  cursor: pointer;");
out.println("  display: block;");
out.println("  margin: 20px auto;");
out.println("  font-size: 16px;");
out.println("}");
out.println("button:hover {");
out.println("  background-color: #45a049;");
out.println("}");
out.println("</style>");

out.println("</head>");
out.println("<body>");
out.println("<h1>Compound Interest Calculation</h1>");


out.println("<table>");
out.println("<tr>");
out.println("<th>Principal Amount</th>");
out.println("<td>" + principalParam+ "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Interest</th>");
out.println("<td>" + interestParam + "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Years</th>");
out.println("<td>" + yearsParam + "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Months</th>");
out.println("<td>" +  monthsParam + "</td>");
out.println("</tr>"); 

out.println("<tr>");
out.println("<th>Compound Interest</th>");
out.println("<td>" + compoundInterest + "</td>");
out.println("</tr>");

out.println("</table>");


out.println("<form action='index.html'>");
out.println("<button type='submit'>Return to Form</button>");
out.println("</form>");

out.println("</body>");
out.println("</html>");
        } 
        catch (Exception e) 
        {
            out.println("<html><body><h3>Error occurred while calculating compound interest.</h3></body></html>");
        }
    }
}
