/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */




import java.io.*;
import java.util.regex.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class myfistwebproject extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve input values
        String principalParam = request.getParameter("Principal");
        String interestParam = request.getParameter("Interest");
        String yearsParam = request.getParameter("Years");
        String monthsParam = request.getParameter("Months");
        String compoundParam = request.getParameter("cars");

        String errorMessage = "";
        long principal = 0;
        double interest = 0.0;
        double time=0.0;
    
        
        
        if (yearsParam.length() == 0 && monthsParam.length() == 0)
                    {
                        errorMessage += "Please Enetr Years and Months must be greater than 0!.......<br>";
                    }
        
        String numericPattern = "^[0-9]+(\\.[0-9]{1,2})?$";  
        Pattern pattern = Pattern.compile(numericPattern);

      
        if (principalParam == null || principalParam.isEmpty()) 
        {
            errorMessage += "Please enter a valid Principal amount.<br>";
        } else
        {
            Matcher matcher = pattern.matcher(principalParam);
            if (matcher.matches()) {
                try {
                    principal = Long.parseLong(principalParam);
                    if (principal <=0) {
                        errorMessage += "Principal amount must be greater than 0.<br>";
                    } else if (principal > 1000000) {
                        errorMessage += "Principal amount cannot be more than 1,000,000.<br>";
                    }
                } catch (NumberFormatException e) {
                    errorMessage += "Invalid Principal amount. Please enter a valid number.<br>";
                }
            } else {
                errorMessage += "Principal must be a valid number.<br>";
            }
        }

    
        
        
        if (interestParam == null || interestParam.trim().isEmpty())
        {
            errorMessage += "Please enter a valid Interest rate.<br>";
        } else 
        {
            Matcher matcher = pattern.matcher(interestParam);
            if (matcher.matches()) 
            {
                try 
                {
                    interest = Double.parseDouble(interestParam);
                    if (interest <=0) 
                    {
                        errorMessage += "Interest rate must be greater than 0.<br>";
                    } else if (interest > 100)
                    {
                        errorMessage += "Interest rate cannot be more than 100%.<br>";
                    }
                } catch (NumberFormatException e)
                {
                    errorMessage += "Invalid Interest rate. Please enter a valid number.<br>";
                }
            } 
            else 
            {
                errorMessage += "Interest must be a valid number.<br>";
            }
        }

       
        
        
        
        
        
       
        
            
            
        
        
        
        
        
        
        if (yearsParam == null || yearsParam.trim().isEmpty())
            {
                errorMessage += "Please enter a valid number of Years.<br>";
            }
        else
        {
        if (monthsParam == null || monthsParam.trim().isEmpty()) 
        {
            errorMessage += "Please enter a valid number of Months.<br>";
        }
        else 
        {
            
            
            try {
                int months = Integer.parseInt(monthsParam);
                 int  years = Integer.parseInt(yearsParam);
                 
                if (months < 0 || months > 11) 
                  {
                    errorMessage += "Months must be between 0 and 11.<br>";
                   }
                
 
                  if (years > 9999)
                    {
                        errorMessage += "Years cannot be more than 9999.<br>";
                    }
                  if(years == 0 && months == 0)
                  {
                       errorMessage +="Enter Years And Months More then 0...!";                  
                  }
                
                time= years + (months / 12.0);
                
            } catch (NumberFormatException e) {
                errorMessage += "Invalid number of Months and Years. Please enter a valid number.<br>";
            }
        }

        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        int compound = 0;
        if (compoundParam == null || compoundParam.trim().isEmpty())
        {
            errorMessage += "Please enter a valid number of Compounds per year.<br>";
        } 
        else 
        {
          
            try 
            {
                compound = Integer.parseInt(compoundParam);
                
                
                int[] validCompoundValues = {4, 365, 360, 52, 26, 24, 12, 6, 2, 1};
                boolean isValid = false;

                for (int value : validCompoundValues) 
                {
                    if (compound == value) 
                    {
                        isValid = true;
                        break;
                    }
                }

                if (!isValid)
                {
                    errorMessage += "Invalid number of Compounds per year. Please select a valid option.<br>";
                }
            } 
            catch (NumberFormatException e)
            {
                errorMessage += "Invalid number of Compounds per year. Please enter a valid number.<br>";
            }
            
        }

        
        if (!errorMessage.isEmpty()) 
        {
            out.println("<html>");
            out.println("<body>");
            out.println("<p>" + errorMessage + "</p>");
            out.println("<form action='index.html'>");
            out.println("<button type='submit'>Return to Form</button>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
            return;  
        }

       
        try {
              
            double compoundInterest = principal * Math.pow((1 + interest / (compound * 100)), compound * time);

            out.println("<html>");
out.println("<head><title>Compound Interest Calculation</title>");
out.println("<style>");
out.println("body {");
out.println("  font-family: Arial, sans-serif;");
out.println("  background-color: #f4f4f9;");
out.println("  margin: 20px;");
out.println("  padding: 20px;");
out.println("}");
out.println("h1 {");
out.println("  color: #4CAF50;");
out.println("  text-align: center;");
out.println("}");
out.println("table {");
out.println("  width: 50%;");
out.println("  margin: 20px auto;");
out.println("  border-collapse: collapse;");
out.println("  background-color: #ffffff;");
out.println("}");
out.println("th, td {");
out.println("  padding: 10px;");
out.println("  text-align: center;");
out.println("  border: 1px solid #ddd;");
out.println("}");
out.println("th {");
out.println("  background-color: ;");
out.println("  color: bleak;");
out.println("}");
out.println("tr:nth-child(even) {");
out.println("  background-color: #f2f2f2;");
out.println("}");
out.println("button {");
out.println("  background-color: #4CAF50;");
out.println("  color: white;");
out.println("  padding: 10px 20px;");
out.println("  border: none;");
out.println("  cursor: pointer;");
out.println("  display: block;");
out.println("  margin: 20px auto;");
out.println("  font-size: 16px;");
out.println("}");
out.println("button:hover {");
out.println("  background-color: #45a049;");
out.println("}");
out.println("</style>");

out.println("</head>");
out.println("<body>");
out.println("<h1>Compound Interest Calculation</h1>");


out.println("<table>");
out.println("<tr>");
out.println("<th>Principal Amount</th>");
out.println("<td>" + principalParam+ "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Interest</th>");
out.println("<td>" + interestParam + "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Years</th>");
out.println("<td>" + yearsParam + "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Months</th>");
out.println("<td>" +  monthsParam + "</td>");
out.println("</tr>"); 

out.println("<tr>");
out.println("<th>Compound Interest</th>");
out.println("<td>" + compoundInterest + "</td>");
out.println("</tr>");

out.println("</table>");


out.println("<form action='index.html'>");
out.println("<button type='submit'>Return to Form</button>");
out.println("</form>");

out.println("</body>");
out.println("</html>");
        } 
        catch (Exception e) 
        {
            out.println("<html><body><h3>Error occurred while calculating compound interest.</h3></body></html>");
        }
    }
}
