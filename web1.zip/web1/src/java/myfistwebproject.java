/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class myfistwebproject extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve input values
        String principalParam = request.getParameter("Principal");
        String interestParam = request.getParameter("Interest");
        String yearsParam = request.getParameter("Years");
        String monthsParam = request.getParameter("Months");
        String compoundParam = request.getParameter("cars");

       
        String errorMessage = "";

        
        long principal ;
         principal = Long.parseLong(principalParam);
         if(principal>0){
         
       try {
           
            if (principal > 1000000) 
            {
                errorMessage += "Principal amount cannot be more than 1000000!<br>";
            }
        } catch (NumberFormatException e)
        {
                errorMessage += "Please enter a valid principal amount (numeric value).<br>";
        }

         }else
         {
         errorMessage += "Principal amount  more than 0!";
         }
         
         
        double interest;
        interest = Double.parseDouble(interestParam);
        if(interest>0){
        try {
            
            if (interest > 100) 
            {
                errorMessage += "Interest cannot be more than 100%.<br>";
            }
        } catch (NumberFormatException e) 
        {
            errorMessage += "Please enter a valid interest rate (numeric value).<br>";
        }
        }
      else
        {
        errorMessage += "Please Enter interest more then 0! .<br>";
        }
        int years ;
        int months ;
        years = Integer.parseInt(yearsParam);
        months = Integer.parseInt(monthsParam);
        
        
        if((years<=0 && months <=0) || years<0 || months>12 )
        {
        
          errorMessage +="Enter Valid Years and Months!<br>";
        }else
        {
        try {
            
            
            if (years > 9999) 
            {
                errorMessage += "Years cannot be more than 9999.<br>";
            }
        } catch (NumberFormatException e)
        {
            errorMessage += "Please enter a valid number of years.<br>";
        }

        
        
        try {
           
            if (months > 11)
            {
                errorMessage += "Months cannot be more than 11.<br>";
            }
        } catch (NumberFormatException e)
        {
            errorMessage += "Please enter a valid number of months (0-11).<br>";
        }
    
        }
        int compound = 0;
        try {
            compound = Integer.parseInt(compoundParam);
        } catch (NumberFormatException e) {
            errorMessage += "Please enter a valid number of compounds per year.<br>";
        }

      
        if (!errorMessage.isEmpty()) {
            out.println("<html>");
            out.println("<body>");
            out.println("<p>" + errorMessage + "</p>");
            out.println("<form action='index.html'>");
            out.println("<button type='submit'>Return to Form</button>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
            return;  
        }

     
        try {
            double time = years + (months / 12.0); 
            double compoundInterest = principal * (1 + interest / (compound * 100)) * compound * time;


out.println("<html>");
out.println("<head><title>Compound Interest Calculation</title>");
out.println("<style>");
out.println("body {");
out.println("  font-family: Arial, sans-serif;");
out.println("  background-color: #f4f4f9;");
out.println("  margin: 20px;");
out.println("  padding: 20px;");
out.println("}");
out.println("h1 {");
out.println("  color: #4CAF50;");
out.println("  text-align: center;");
out.println("}");
out.println("table {");
out.println("  width: 50%;");
out.println("  margin: 20px auto;");
out.println("  border-collapse: collapse;");
out.println("  background-color: #ffffff;");
out.println("}");
out.println("th, td {");
out.println("  padding: 10px;");
out.println("  text-align: center;");
out.println("  border: 1px solid #ddd;");
out.println("}");
out.println("th {");
out.println("  background-color: ;");
out.println("  color: bleak;");
out.println("}");
out.println("tr:nth-child(even) {");
out.println("  background-color: #f2f2f2;");
out.println("}");
out.println("button {");
out.println("  background-color: #4CAF50;");
out.println("  color: white;");
out.println("  padding: 10px 20px;");
out.println("  border: none;");
out.println("  cursor: pointer;");
out.println("  display: block;");
out.println("  margin: 20px auto;");
out.println("  font-size: 16px;");
out.println("}");
out.println("button:hover {");
out.println("  background-color: #45a049;");
out.println("}");
out.println("</style>");

out.println("</head>");
out.println("<body>");
out.println("<h1>Compound Interest Calculation</h1>");


out.println("<table>");
out.println("<tr>");
out.println("<th>Principal Amount</th>");
out.println("<td>" + principalParam+ "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Interest</th>");
out.println("<td>" + interestParam + "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Years</th>");
out.println("<td>" + yearsParam + "</td>");
out.println("</tr>");


out.println("<tr>");
out.println("<th>Months</th>");
out.println("<td>" +  monthsParam + "</td>");
out.println("</tr>"); 

out.println("<tr>");
out.println("<th>Compound Interest</th>");
out.println("<td>" + compoundInterest + "</td>");
out.println("</tr>");

out.println("</table>");


out.println("<form action='index.html'>");
out.println("<button type='submit'>Return to Form</button>");
out.println("</form>");

out.println("</body>");
out.println("</html>");


        } catch (Exception e) {
            out.println("<html><body><h3>Error occurred while calculating compound interest.</h3></body></html>");
        }
    }
}
