import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        HttpSession session = request.getSession();
        
        String name = (session != null && session.getAttribute("username") != null) ? 
                      (String) session.getAttribute("username") : "Guest";
        
        Date startTime = (session != null) ? (Date) session.getAttribute("startTime") : null;
        Date endTime = new Date();
        
        long duration = (startTime != null) ? (endTime.getTime() - startTime.getTime()) / 1000 : 0;
        
        if (session != null) {
            session.invalidate();
        }

        out.println("<html><head><title>Logout</title>");
        out.println("<style>body { font-family: Arial, sans-serif; text-align: center; margin-top: 100px; }</style>");
        out.println("</head><body>");
        
        out.println("<h2>Thank You, " + name + "!</h2>");
        out.println("<p>Your session lasted " + duration + " seconds.</p>");
        out.println("<a href='index.html'>Go to Home</a>");
        
        out.println("</body></html>");
    }
}
